const database = require('./database')
console.log(database.supplies)